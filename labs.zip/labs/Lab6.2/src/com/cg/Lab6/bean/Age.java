package com.cg.Lab6.bean;

class AgeException extends Exception 
{
	AgeException(String s)
	{
		super(s);
	}
}
public class Age {
	private int age;

	public Age(int age) {
		super();
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
public void validate() throws AgeException
{
	if(age<=15)
	{
		throw new AgeException("Age must be above 15");
	}
	else
		System.out.println("Age is:"+ age);
}

}
