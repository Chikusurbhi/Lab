package com.cg.Lab7.bean;

import java.util.*;

public class SquareusingForeach {

	public static void main(String[] args) {
		 Scanner scanner= new Scanner(System.in);
		 int i;
		 String s;
		 System.out.println("Enter the product name in  ArrayList");
		 ArrayList<String> list1 =new ArrayList<String>();
		 for(i=0;i<5;i++) {
			 s= scanner.nextLine();
			 list1.add(s);
		 }
		 SquareusingForeach u= new SquareusingForeach();
		 u.sortNames(list1);

	}

	private void sortNames(ArrayList<String> list1) {
		
		ArrayList<String> list11= new ArrayList<String>();
		list11.addAll(list1);
		Collections.sort(list1);
		for(String s:list11)
		{
			System.out.println(s);
		}
	}
}
