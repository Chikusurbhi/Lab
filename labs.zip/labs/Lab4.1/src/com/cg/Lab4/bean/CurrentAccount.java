package com.cg.Lab4.bean;

public class CurrentAccount {

}
