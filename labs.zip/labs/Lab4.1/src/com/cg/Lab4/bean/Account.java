package com.cg.Lab4.bean;

public class Account {
	private long accNum;
	private double balance;
	private Person accholder;
	
	public Account(long accNum, double balance, Person accholder) {
		this.accNum = accNum;
		this.balance = balance;
		this.accholder = accholder;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccholder() {
		return accholder;
	}
	public void setAccholder(Person accholder) {
		this.accholder = accholder;
	}
	void deposit(double bal)
	{
		this.balance=balance+bal;
	}
	void withdraw(double bal)
	{
		this.balance= balance-bal;
	}
	double getbalance()
	{
		return this.balance;
	}
	public void SetAccnum()
	{
		long x=(long)(Math.random()*10000);
		this.accNum=x;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance + ", accholder=" + accholder + "]";
	}
	

}
