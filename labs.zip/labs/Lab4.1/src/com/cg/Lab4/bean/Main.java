package com.cg.Lab4.bean;

public class Main {

	public static void main(String[] args) {
	
	Account Smith=new Account(123456,2000,new Person("Smith",23));
	Account Kathy=new Account(354677,3000,new Person("Kathy",22));
	System.out.println(Smith.getbalance());
	System.out.println(Kathy.getBalance());
	Smith.SetAccnum();
	Kathy.SetAccnum();
	Smith.deposit(2000);
	Kathy.withdraw(2500);
	System.out.println("Updated balance of Smith"+Smith.getbalance());
	System.out.println("Updated balance of Kathy"+Kathy.getbalance());

	}

}
