package com.cg.lab7.bean;

import java.util.HashMap;
import java.util.Scanner;

public class Square {

	public static void main(String[] args) {
		Scanner scanner= new Scanner(System.in);
		int array[]=new int[10];
		System.out.println("Enter the elements");
		for(int i=0;i<10;i++)
		{
			array[i]=scanner.nextInt();
		}
		Square sqr= new Square();
		HashMap<Integer,Double> hashmap= new HashMap<Integer,Double>();
		
		hashmap= sqr.getSquare(array);
		System.out.println(hashmap);
		
	}

	private HashMap<Integer, Double> getSquare(int[] array)
	{
		HashMap<Integer,Double> hashmap= new HashMap<Integer,Double>();
		int i;
		for(i=0;i<array.length;i++)
			hashmap.put(array[i], Math.pow(array[i],2));
		
		return hashmap;
	}
	
	

}
