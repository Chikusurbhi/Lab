package com.cg.Lab2project.ui; 

import com.cg.Lab2.bean.Person1;

public class PersonMain {

	public static void main(String[] args) {
	
		Person1 person2= new Person1("Rohan","Mehra",'M');
		
		/*person2.setFirstName("Aditi");
		person2.setLastName("Priya");
		person2.setGender('f');
		
		System.out.println("Person's first name is:" + person2.getFirstName());
		System.out.println("Person's last name is:" + person2.getLastName());
		System.out.println("Person's gender is:" + person2.getGender());
		*/
		System.out.println(person2);
	}

	

} 
