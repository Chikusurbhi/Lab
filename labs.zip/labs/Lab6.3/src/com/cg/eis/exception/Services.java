package com.cg.eis.exception;

import com.cg.eis.bean.Employee;

public interface Services {

	public Employee setDetails();
    public void insurancescheme(int salary, String designaton, Employee e);
    public void getDetails();
}
