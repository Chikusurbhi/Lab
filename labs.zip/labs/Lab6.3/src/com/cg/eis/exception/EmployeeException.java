package com.cg.eis.exception;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

class SalaryException extends Exception 
{
	SalaryException(String s)
	{
		super(s);
	}
}
public class EmployeeException {
	Employee e;
	int salary=0;
	
	public Employee setDetails() {
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the employee's name:");
		String name=s.next();
		System.out.println("Enter the employee's id");
		int id= s.nextInt();
		System.out.println("Ener the employee's designation");
		String designation =s.next();
		System.out.println("Enter the employee's salary");
		int salary= s.nextInt();
		System.out.println("Enter the insurance scheme");
		String insurancescheme= s.next();
		e=new Employee(id,name,salary,designation,insurancescheme);
		return e;	
		}

		public void insurancescheme(int salary, String designation, Employee a)
		{
			
			if(designation.equals("System Associate")&&(salary>5000 && salary<20000))
			{
				a.setInsurancescheme("A");
			}
			else if(designation.equals("Programmer")&&(salary>=20000 && salary<40000))
			{
				a.setInsurancescheme("B");
			}
			else if(designation.equals("Manager")&&(salary>=40000))
			{
				a.setInsurancescheme("C");
			}
			else if(designation.equals("Clerk")&&(salary<5000))
			{
				a.setInsurancescheme("NO");
			}
		}

		public void getDetails() {
			System.out.println("Employee name is"+e.getName());
			System.out.println("Employee id is"+e.getId());
			System.out.println("Employee salary is"+e.getSalary());
			System.out.println("Employee designation is"+e.getDesignation());
			System.out.println("Employee insurance is"+e.getInsurancescheme());
			}
		
		
		
		public void validate() throws SalaryException
		{
			if(salary<3000)
			{
				throw new SalaryException("Age must be above 3000");
			}
			else
				System.out.println("Salary is:"+ salary);
		}
}
