package com.cg.lab8.bean;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Random t1=new Random();
     Random t2=new Random();
     t1.start();
     t2.start();
	}
}
