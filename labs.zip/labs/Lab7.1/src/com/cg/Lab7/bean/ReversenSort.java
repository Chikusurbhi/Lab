package com.cg.Lab7.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ReversenSort {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of elements : ");
		int a=sc.nextInt();
		int p=0;
		ArrayList<Integer> al=new ArrayList<Integer>();
		System.out.println("Enter the elements : ");
		for(int i=0;i<a;i++)
		{
			int a1=sc.nextInt();
			al.add(a1);
			System.out.println(al);
		}
		for(int j : al)
		{
			String s=Integer.toString(j);
			StringBuilder sb=new StringBuilder(s);
			sb.reverse();
			String s1=new String(sb);
			Integer in=Integer.parseInt(s1);
			al.set(p, in);
			p++;
		}
		System.out.println("Reverse array is : " +al);
		Collections.sort(al);
		System.out.println("Reverse sorted array is : "+al);
		

	}

}
