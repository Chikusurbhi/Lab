package com.cg.Lab4.bean;

public class SavingsAccount extends Account {
	final int minbalance=100;
	boolean withdraw(int balance)
	{
		if(balance<minbalance)
			return false;
		else
		{
			super.balance-=balance;
			System.out.println("Balance after withdraw:"+this.balance);
			return true;
		}
	}

}
