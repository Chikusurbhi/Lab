package com.cg.Lab4.bean;

public class Main {

	public static void main(String[] args) {
	SavingsAccount s=new SavingsAccount();
	System.out.println(s.withdraw(300));
	CurrentAccount c=new CurrentAccount();
	System.out.println(c.withdraw(2000));

	}

}
