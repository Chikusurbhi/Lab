package com.cg.Lab4.bean;

public class Account {
	
	boolean withdraw(double bal)
	{
		return true;
	}
	int balance=5275;
}
