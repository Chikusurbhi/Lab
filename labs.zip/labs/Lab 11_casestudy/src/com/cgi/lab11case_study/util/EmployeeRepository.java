package com.cgi.lab11case_study.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.*;

import com.cgi.lab11case_study.bean.*;

public class EmployeeRepository {
private static List<Employee> employeeList;
	
	static {
		prepareEmployeeList();
	}
	
	private static void prepareEmployeeList() {
		employeeList = new ArrayList<>();
		employeeList.add(new Employee(101,"Ramesh","Mishra","rameshmishra@gmail.com","9999999999",LocalDate.of(2010, Month.JUNE, 12),"Assistant Software Engineer",40000.0,101,new Department(1001,"Software Development",101)));
		employeeList.add(new Employee(102,"Raman","Bhalla","ramanbhalla@gmail.com","1234567890",LocalDate.of(2013, Month.JANUARY, 3),"Assistant Quality Engineer",35000.0,102,new Department(1002,"Software Testing",102)));
		employeeList.add(new Employee(103,"Soumya","Sharma","soumyasharma@gmail.com","2334455676",LocalDate.of(2014, Month.APRIL, 10),"Senior Software Engineer",50000.0,103,new Department(1001,"Software Development",103)));
		employeeList.add(new Employee(104,"Raman","Raghav","ramanraghav@gmail.com","8743234566",LocalDate.of(2016, Month.MARCH, 17),"Human & Resource Manager",65000.0,104,new Department(1004,"HR Department",104)));
		employeeList.add(new Employee(105,"Shivangi","Tripathi","shivangitripathi@gmail.com","7895167416",LocalDate.of(2019, Month.JANUARY, 16),"Full Stack Developer",30000.0,105,new Department(1003,"Software Development",105)));
	}

	public static List<Employee> getEmployeeList() {
		return employeeList;
	}
}
