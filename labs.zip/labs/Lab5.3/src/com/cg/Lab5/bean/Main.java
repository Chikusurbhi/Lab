package com.cg.Lab5.bean;

//import com.cg.Lab5.bean.Account.Person;

public class Main {

	public static void main(String[] args)
	{
		Person p= new Person();
		p.deposit(6000);
		p.withdraw(3000);
		System.out.println("Balance is:"+p.getBalance());

	}

}
