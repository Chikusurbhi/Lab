package com.cg.Lab5.bean;

public abstract class Account
{
	private long accNum;
	protected double balance;
	private String accholder;
	private int miniBalance=500;
	
	abstract void withdraw(double balw);
	abstract void deposit(double bald);
}
class Person extends Account
{
     public double getBalance()
     {
    	 return balance;
     }
     public void setBalance(double balance)
     {
    	 this.balance=balance;
     }
	@Override  
	void withdraw(double balw) {
		if(balance-balw>=500)
		{
			balance=balance-balw;
		}
	}
	
	

	@Override
	void deposit(double bald) {
		balance= balance+bald;
	}
		void getbalance()
		{
			System.out.println(balance);
		}
	}

