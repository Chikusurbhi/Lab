package com.capg.eleven_1;

public interface PowInterface {
public double power(double x,double y);
	
}
