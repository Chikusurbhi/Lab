package com.capg.eleven_3;

public interface ILoginOperation {
boolean login(String uname, String pass);

}
