package com.capg.eleven_two;

public abstract class StringSpace implements IStringSpace {
    public static void main(String[] args) {
	 
    	IStringSpace e = (tring)->{ System.out.println(tring.replace(""," "));};
    	e.space("hai");
}
    
}